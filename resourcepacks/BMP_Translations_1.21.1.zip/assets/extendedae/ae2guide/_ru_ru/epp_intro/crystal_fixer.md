---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Восстановитель кристаллов
    icon: extendedae:crystal_fixer
categories:
- extended devices
item_ids:
- extendedae:crystal_fixer
---

# ME Восстановитель кристаллов

<BlockImage id="extendedae:crystal_fixer" scale="8"></BlockImage>

ME Кристальный Фиксатор может восстанавливать расцветающий цертусовый блок и превращать его в улучшенный.

Ему требуются <ItemLink id="ae2:charged_certus_quartz_crystal" /> и энергия для работы. Щелкните по нему правой кнопкой мыши с помощью <ItemLink id="ae2:charged_certus_quartz_crystal" /> для ввода.

<Row gap="20">
<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/crystal_fixer.snbt"></ImportStructure>
</GameScene>
</Row>

---
