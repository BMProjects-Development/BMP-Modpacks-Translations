---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Крошечный ТНТ
  icon: tiny_tnt
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:tiny_tnt
---

# Крошечный ТНТ

<BlockImage id="tiny_tnt" scale="8" />

Небольшой ТНТ для небольших взрывов. Полезен для создания пар <ItemLink id="quantum_entangled_singularity" />.

В конфигурации может быть отключен блочный урон, что позволяет создавать сингулярности без возможности
если вы хотите отключить TNT и криперов на своем сервере.

## Рецепт

<RecipeFor id="tiny_tnt" />
