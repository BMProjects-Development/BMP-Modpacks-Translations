---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Токовые инструменты
  icon: fluix_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_axe
- ae2:fluix_hoe
- ae2:fluix_shovel
- ae2:fluix_pickaxe
- ae2:fluix_sword
---

# Токовые инструменты

<Row>
  <ItemImage id="fluix_axe" scale="4" />

  <ItemImage id="fluix_hoe" scale="4" />

  <ItemImage id="fluix_shovel" scale="4" />

  <ItemImage id="fluix_pickaxe" scale="4" />

  <ItemImage id="fluix_sword" scale="4" />
</Row>

[Токовые](fluix_crystal.md) инструменты занимают место между железными и алмазными инструментами. У них в 3 раза больше прочности и повышенная атака и скорость атаки, по сравнению с железными.

Все токовые инструменты действует, как если бы на них были наложены чары Удачи/Добычи I. Полезно, если у вас нет доступа к чародейскому столу.

Вам нужен <ItemLink id="fluix_upgrade_smithing_template" /> для создания

## Рецепты

<Column>
  <Row>
    <RecipeFor id="fluix_axe" />

    <RecipeFor id="fluix_hoe" />

    <RecipeFor id="fluix_shovel" />
  </Row>

  <Row>
    <RecipeFor id="fluix_pickaxe" />

    <RecipeFor id="fluix_sword" />
  </Row>
</Column>
