---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Токовый кузнечный шаблон
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# Токовый кузнечный шаблон

В отличии от ванильных кузнечных шаблонов, этот шаблон можно создать с нуля.

Требуется для создания [токовых инструментов](fluix_tools.md)

## Рецепт

<RecipeFor id="fluix_upgrade_smithing_template" />