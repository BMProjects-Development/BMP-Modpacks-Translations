---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Руководство
  icon: guide
categories:
- tools
item_ids:
- ae2:guide
---

# Руководство

<ItemImage id="guide" scale="8" />

### Это руководство, которое вы читаете сейчас, для всех ваших нужд по AE2.

* Для доступа к оглавлению используйте боковую панель слева.
* Многие страницы содержат интерактивные сцены. Если сцена имеет ![Плюс](../assets/diagrams/plus.png)
  и ![Минус](../assets/diagrams/minus.png) (увеличение) рядом с ней кнопки, вы можете вращать и перемещать камеру.
Щелкните левой кнопкой мыши и перетащите для вращения, щелкните правой кнопкой мыши и перетащите для перемещения.

## Recipe

<RecipeFor id="guide" />
