---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Заряженный кристалл истинного кварца
  icon: charged_certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:charged_certus_quartz_crystal
---

# Заряженный кристалл истинного кварца

<ItemImage id="charged_certus_quartz_crystal" scale="4" />

<ItemLink id="certus_quartz_crystal" />, пропущенный через <ItemLink id="charger" />. Используется при производстве
<ItemLink id="fluix_crystal" /> и [цветущих блоков истинного кварца](../items-blocks-machines/budding_certus.md).

## Рецепт

<RecipeFor id="charged_certus_quartz_crystal" />
