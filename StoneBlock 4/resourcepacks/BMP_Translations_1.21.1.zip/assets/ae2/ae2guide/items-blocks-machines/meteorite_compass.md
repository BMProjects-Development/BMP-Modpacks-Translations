---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Метеоритный компасс
  icon: meteorite_compass
  position: 410
categories:
- tools
item_ids:
- ae2:meteorite_compass
---

# Метеоритный компасс

<ItemImage id="meteorite_compass" scale="4" />

Метеоритный компас указывает на ближайший <ItemLink id="mysterious_cube" />, таким образом указывая на ближайший
[метеорит](../ae2-mechanics/meteorites.md). Это один из первых предметов AE2, который следует создать.

## Рецепт

<RecipeFor id="meteorite_compass" />
