---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Пыль небесного камня
  icon: sky_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_dust
---

# Пыль небесного камня

<ItemImage id="sky_dust" scale="4" />

<ItemLink id="sky_stone_block" />, который был раздроблен <ItemLink id="inscriber" />. Используется при производстве
<ItemLink id="cell_component_256k" /> и <ItemLink id="sky_stone_block" />.

Его также можно получить, направив <ItemLink id="annihilation_plane" /> вверх на пределе мировой высоты.

## Рецепт

<RecipeFor id="sky_dust" />
