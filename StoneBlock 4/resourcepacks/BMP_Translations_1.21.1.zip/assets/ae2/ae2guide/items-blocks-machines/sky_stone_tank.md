---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Бак из небесного камня
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# Бак из небесного камня

<BlockImage id="sky_stone_tank" scale="8" />

Это резервуар для хранения жидкости, вмещающий 16 ведер. Не сохраняет содержимое при подъеме. Больше сказать нечего.

## Рецепт

<RecipeFor id="sky_stone_tank" />
