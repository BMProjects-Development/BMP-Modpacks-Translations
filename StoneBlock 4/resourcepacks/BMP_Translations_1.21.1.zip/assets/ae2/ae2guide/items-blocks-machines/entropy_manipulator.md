---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Манипулятор энтропии
  icon: entropy_manipulator
  position: 410
categories:
- tools
item_ids:
- ae2:entropy_manipulator
---

# Манипулятор энтропии

<ItemImage id="entropy_manipulator" scale="4" />

Манипулятор энтропии может нагревать и охлаждать по щелчку ПКМ и ПКМ крадучись соответственно. Не может делать что-то по-настоящему крутое,
только испарять и замораживать воду, отвердевать лаву в обсидиан, сжигать брёвна в древесный уголь, и плавить булыжник в камень.

Если для манипулятора не написано специальное поведение, то он будет работать как огниво.

Заряжается в  <ItemLink id="charger" />.

## Recipe

<RecipeFor id="entropy_manipulator" />
