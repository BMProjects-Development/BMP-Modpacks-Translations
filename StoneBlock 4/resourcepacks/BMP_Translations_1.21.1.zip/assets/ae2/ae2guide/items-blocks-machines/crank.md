---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Рукоятка
  icon: crank
  position: 310
categories:
- machines
item_ids:
- ae2:crank
---

# Рукоятка

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/crank_on_stuff.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Рукоятка используется для приведения в действие механизмов, когда у вас нет другого доступа к энергии (или <ItemLink id="energy_acceptor" />). Борьба в начале игры, я прав?

## Рецепт

<RecipeFor id="crank" />
