---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Карта памяти
  icon: memory_card
  position: 410
categories:
- tools
item_ids:
- ae2:memory_card
---

# Карта памяти

<ItemImage id="memory_card" scale="4" />

Карта памяти используется для копирования и вставки настроек между AE2 [устройствами](../ae2-mechanics/devices.md), а также для соединения
[P2P туннелей](p2p_tunnels.md). Он также может вставлять в устройства [карты улучшений](upgrade_cards.md).

- Щелкните правой кнопкой мыши, чтобы скопировать настройки или сгенерировать новую частоту связывания P2P.
- Щелкните правой кнопкой мыши, чтобы вставить настройки, карты обновления или частоту связей.

## Рецепт

<RecipeFor id="memory_card" />
