---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Изменчивый кристалл
  icon: fluix_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_crystal
---

# Изменчивый кристалл

<ItemImage id="fluix_crystal" scale="4" />

*"Изменчивые кристаллы обладают уникальной способностью поглощать и преобразовывать энергию из одной формы в другую и являются основой
всех технологий использования энергии материи "*.

Один из основных ингредиентов блоков, [устройств](../ae2-mechanics/devices.md) и предметов AE2. Изготавливается путем метания кварца нетера, красного камня и
<ItemLink id="charged_certus_quartz_crystal" /> в воду.

Его можно [автоматизировать](../example-setups/throw-in-water-automation.md), используя <ItemLink id="formation_plane" /> и <ItemLink id="annihilation_plane" />.

## Рецепты

<Row>
  <Recipe id="transform/fluix_crystals" />

  <Recipe id="transform/fluix_crystal" />

  <Recipe id="misc/deconstruction_fluix_block" />
</Row>
