---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Заряженный посох
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# Заряженный посох

<ItemImage id="charged_staff" scale="4" />

Заряженный посох — это палка с <ItemLink id="charged_certus_quartz_crystal" /> на конце. Она наносит 6 урона за 300 AE за одно использование.

Заряжается в <ItemLink id="charger" />.

## Рецепт

<RecipeFor id="charged_staff" />
