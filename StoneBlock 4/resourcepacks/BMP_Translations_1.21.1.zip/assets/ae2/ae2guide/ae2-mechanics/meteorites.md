---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Метеориты
  icon: sky_stone_block
---

# Метеориты

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/meteor_interior.snbt" />
</GameScene>

Метеориты являются отправной точкой для использования AE2. Они предоставляют критически важные материалы: [цветущие блоки истинного кварца](../items-blocks-machines/budding_certus.md)
oразличных типов и <ItemLink id="mysterious_cube" /> в центре.

[Начало начал](../getting-started.md) предоставит информацию о том, что делать, когда вы его найдете.

## Поиск метеоритов

Метеориты встречаются довольно часто и оставляют в земле огромные дыры, так что, возможно, вы уже нашли несколько штук. Если нет,
<ItemLink id="meteorite_compass" /> укажет на ближайший таинственный куб.

![Метеоритный кратер](../assets/assemblies/meteorite-crater.png)